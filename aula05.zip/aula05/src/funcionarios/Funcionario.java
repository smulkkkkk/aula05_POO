package funcionarios;

public class Funcionario {

}
