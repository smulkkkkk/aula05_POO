package funcionarios;

public class TestaFuncionario {

}
