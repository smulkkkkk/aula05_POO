package funcionarios;

public class Assistente {

}
