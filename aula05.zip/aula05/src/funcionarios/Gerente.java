package funcionarios;

public class Gerente {

}
